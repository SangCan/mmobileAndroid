const client = contentful.createClient({
  // This is the space ID. A space is like a project folder in Contentful terms
  space: "le38p0evk9pd",
  // This is the access token for this space. Normally you get both ID and the token in the Contentful web app
  accessToken: "hof24Z_9c3_U4jdDf-NzuKjoREd1tHxCoAgB2zTGr98"
}); 

console.log("hi: " + client.);

// class Products {
//   async getProducts(){
//     try{
//       let contentful = await client.getEntries({
//         content_type:"";
//       });
      
//     }catch(error){
//       console.log(error);
//     }
//   }
// }