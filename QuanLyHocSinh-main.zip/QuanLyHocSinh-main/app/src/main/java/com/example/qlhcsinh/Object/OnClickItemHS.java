package com.example.qlhcsinh.Object;

import com.example.qlhcsinh.Object.HocSinh;

public interface OnClickItemHS {
    public void onClick(HocSinh hocSinh);
    public void onLongClick(HocSinh hocSinh);
}
