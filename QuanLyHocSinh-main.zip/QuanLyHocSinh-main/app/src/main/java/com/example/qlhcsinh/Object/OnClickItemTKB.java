package com.example.qlhcsinh.Object;

public interface OnClickItemTKB {
    public void onClick(TKB tkb);
}
